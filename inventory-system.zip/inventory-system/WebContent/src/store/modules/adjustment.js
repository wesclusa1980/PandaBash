/**
 * Created by weiming on 14/5/17.
 */
import * as types from '../mutation-types'
import { log } from '../../utils/utils';
import * as s from '../../utils/setting'

const state = {
};

const getters = {
  adjustStatuses: state => s.ADJUST_STATUSES
};

const mutations = {
};

const actions = {
};

export default {
  state,
  getters,
  mutations,
  actions
}
