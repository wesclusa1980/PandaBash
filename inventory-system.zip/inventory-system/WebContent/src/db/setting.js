/**
 * Created by zhuang_w-pc on 5/2/2017.
 */
export const PRODUCTS = 'products';
export const VARIANTS = 'variants';
export const PURCHASE_ORDERS = 'purchaseOrders';
export const RECOMMENDATION = 'recommendation';
export const WAREHOUSE = 'warehouses';
export const CELL_VARAINT_JOINS = 'cellVariantJoins';

export const SHELVES = 'shelves';
export const LAYERS = 'layers';
export const CELLS = 'cells';