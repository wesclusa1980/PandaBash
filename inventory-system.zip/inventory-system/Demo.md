#Demo

1. Login using purchasing crew --> Purchasing dashboard
2. Purchasing Dashboard contents: 
  - To purchase new
  - To reorder
  - Handle adjustments
3. To purchase new / reorder:
  - Auto fill recommended items
  - Show demand forecast
  - Create a new purchase order

4. Inbound:
  - Receive
  - Check
  - Store